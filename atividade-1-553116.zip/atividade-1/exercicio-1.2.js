let nomes = ["Dino", "Baby", "Charlote"]

let nomeCompleto = nomes.map (item => item + " da Silva Sauro")
//Coloquei um espaço antes da array pra ficar um espaço.
//Eu também poderia usar vírgula, mas vimos em sala a soma então deixei assim.

console.log(nomeCompleto);