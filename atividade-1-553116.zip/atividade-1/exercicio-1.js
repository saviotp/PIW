let arrayNumeros = []

for (let i = 23; i < 53; i++) {
    arrayNumeros.push(i)
    //Na atividade, os números são impressos um a um fora do array, então fiquei confuso
    //Preferi colocar todos dentro do array a partir do contador e imprimir no fim
    //Foi a única que fiquei em dúvida, pois achei o enunciado confuso kk
    //Escrevi e executei usando o Programiz, assim como todas as outras atividades a seguir
}

console.log(arrayNumeros)