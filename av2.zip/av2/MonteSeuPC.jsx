import { useEffect, useState } from "react"

export default function MonteSeuPC() {
    
    const [processador, setProcessador] = useState("Não Selecionado");
    const [memoria, setMemoria] = useState("Não Selecionado");
    const [armazenamento, setArmazenamento] = useState("Não Selecionado");

    const pecas = {
        processadores: [
            { id: 'p1', nome: 'Intel Core i5', preco: 850.00 },
            { id: 'p2', nome: 'Intel Core i7', preco: 1350.00 },
            { id: 'p3', nome: 'AMD Ryzen 5', preco: 800.00 },
            { id: 'p4', nome: 'AMD Ryzen 7', preco: 1250.00 },
        ],
        memoriasRAM: [
            { id: 'm1', nome: '8GB DDR4', preco: 250.00 },
            { id: 'm2', nome: '16GB DDR4', preco: 450.00 },
            { id: 'm3', nome: '32GB DDR4', preco: 900.00 },
        ],
        armazenamentos: [
            { id: 'a1', nome: 'SSD 240GB', preco: 200.00 },
            { id: 'a2', nome: 'SSD 480GB', preco: 350.00 },
            { id: 'a3', nome: 'HD 1TB', preco: 300.00 },
        ]
        };

    return (
        <>
            <div>
                <h1>Monte seu PC</h1>
                <h3>Processador</h3>
                <select name="processadores" id="processadores" value={processador.id} onChange={e => setProcessador(e.target.value)}>
                    <option value="vazio"> Selecione uma Opção </option>
                    {pecas.processadores.map (item => (
                            <option id={item.id} nome={item.nome} preco={item.preco}>{item.id} {item.nome} (R$ {item.preco})</option>
                    ))}
                </select>

                <h3>Memória</h3>
                <select name="memoria" id="memoria" value={memoria} onChange={e => setMemoria(e.target.value)}> 
                    <option value="vazio"> Selecione uma Opção </option>
                    {pecas.memoriasRAM.map (item => (
                            <option id={item.id} nome={item.nome} preco={item.preco}>{item.nome} (R$ {item.preco})</option>
                    ))}
                </select>

                <h3>Armazenamento</h3>
                <select name="armazenamento" id="armazenamento" value={armazenamento} onChange={e => setArmazenamento(e.target.value)}>
                    <option value="vazio"> Selecione uma Opção </option>
                    {pecas.armazenamentos.map (item => (
                            <option id={item.id} nome={item.nome} preco={item.preco}>{item.nome} (R$ {item.preco})</option>
                        ))}
                </select>

                <h2>Resumo da Montagem</h2>

                <p>Processador: {pecas.processadores.filter( (item) => {
                    console.log(item);
                    console.log(processador);
                    return item.id == processador.id
                })}</p>

                <p>Memória: {memoria}</p>

                <p>Armazenamento: {armazenamento}</p>

                <h2>Preco Total: </h2>
            </div>
        </>
    )
}