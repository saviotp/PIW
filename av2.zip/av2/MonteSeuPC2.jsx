import { use, useEffect, useState } from "react";

export default function MonteSeuPC2() {

    const [itens, setItens] = useState([]);
    const [processador, setProcessador] = useState(0);

    const pecas = {
        processadores: [
            { id: 'p1', nome: 'Intel Core i5', preco: 850.00 },
            { id: 'p2', nome: 'Intel Core i7', preco: 1350.00 },
            { id: 'p3', nome: 'AMD Ryzen 5', preco: 800.00 },
            { id: 'p4', nome: 'AMD Ryzen 7', preco: 1250.00 },
        ],
        memoriasRAM: [
            { id: 'm1', nome: '8GB DDR4', preco: 250.00 },
            { id: 'm2', nome: '16GB DDR4', preco: 450.00 },
            { id: 'm3', nome: '32GB DDR4', preco: 900.00 },
        ],
        armazenamentos: [
            { id: 'a1', nome: 'SSD 240GB', preco: 200.00 },
            { id: 'a2', nome: 'SSD 480GB', preco: 350.00 },
            { id: 'a3', nome: 'HD 1TB', preco: 300.00 },
        ]
        };

        useEffect ( () => {
            
        }, [itens])


        return (
            <div>
                <h1>Monte Seu Pc</h1>
                <h3>Processador:</h3>
                <select name="" id="">
                    <option value={processador.id} onChange={e => setProcessador(e.target.value)}>Selecione uma opção:</option>
                    {pecas.processadores.map (item => (
                        <option value="">{item.nome} (R$ {item.preco})</option>
                    ))}
                </select>

                <h3>Memoria:</h3>
                <select name="" id="">
                    <option value="">Selecione uma opção:</option>
                    {pecas.memoriasRAM.map (item => (
                        <option value="">{item.nome} (R$ {item.preco})</option>
                    ))}
                </select>

                <h3>Armazenamento:</h3>
                <select name="" id="">
                    <option value="">Selecione uma opção:</option>
                    {pecas.armazenamentos.map (item => (
                        <option value="">{item.nome} (R$ {item.preco})</option>
                    ))}
                </select>
            </div>
        )
}