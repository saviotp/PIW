import { useState } from "react";

export default function Emojis() {

    let listaEmojis = [
        "😀", "😂", "😍", "🥺", "😎", // Emoções
        "👍", "👏", "🙏", "🤝", "💪", // Gestos
        "🐶", "🐱", "🐰", "🦊", "🐼", // Animais
        "🌞", "🌧️", "🌈", "❄️", "🌪️", // Clima
        "🍎", "🍕", "🍔", "🍩", "🍉", // Comida
        "🚗", "✈️", "🚀", "🚲", "🚉", // Transporte
        "⚽", "🏀", "🎮", "🎸", "🎲", // Esportes e jogos
        "📱", "💻", "📷", "🎧", "🖱️", // Tecnologia
        "🏠", "🏢", "🏕️", "🏰", "🗽", // Lugares
        "❤️", "💔", "💯", "🎉", "🔥"  // Símbolos e expressões
      ];

    const [emojis, setEmojis] = useState(["😊"])


    function addEmoji() {
        console.log("clicou!")

        let iEmoji = Math.floor(Math.random() * listaEmojis.length)

        emojis.push(listaEmojis[iEmoji]);

        setEmojis([...emojis]);

        console.log(emojis);
    }

    return (
        <div>
            <span style={{ fontSize: 80 }}>{emojis}</span>
            <button onClick={addEmoji}>Add Emoji</button>
        </div>
    )
}