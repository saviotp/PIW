import './App.css'

/*EXPORT-DEFAULT
import BoasVindas from './BoasVindas'
import CadastroUsuario from './CadastroUsuario'
import ListarUsuario from './ListarUsuario'
import ListarNomes from './ListarNomes';
import ListaCores from './ListaCores';
*/



/* SHOPPING-CART
import ShoppingListCart from './shopping-list/ShoppingListCart';
import ShoppingListItem from './shopping-list/ShoppingListItem'
*/



/* CONTADOR
import Contador from './Contador'
import ChangeFace from './ChangeFace'
*/

function App() {

  /* EXPORT-DEFAULT
  let usuarioDB = "Sidartha";

  let usuarioSistema = {nome: "Sidartha", email: "sidartha@ufc.br", curso: "Design Digital"}

  let nomesUsuarios = ["Joao", "Maria", "Pedro", "Roger"]

  let nomesCores = ["green", "blue", "salmon", "red", "yellow"]

  return (
    <> 
      <h1>PIW 01 - UFC Quixadá</h1>
      <BoasVindas nomeUsuario = {usuarioDB}/>
      <CadastroUsuario />
      <ListarUsuario usuario = {usuarioSistema}/>
      <ListarNomes arrayNomes = {nomesUsuarios}/>
      <ListaCores arrayCores = {nomesCores}/>
    </>
  )
  */
  


  /* SHOPPING CART
  let listaProdutos = [
    {nome: "Pão", quantidade: 2, comprado: true},
    {nome: "Pizza", quantidade: 2, comprado: false},
    {nome: "Queijo de Cabra", quantidade: 2, comprado: true},
    {nome: "Gorgonzola", quantidade: 2, comprado: false},
    
  ];

  return (
    <>
      <ShoppingListItem nomeProduto = "Pão" quantidadeProduto = {2} comprado = {true} />
      <ShoppingListCart listaProdutos={listaProdutos} />
    </>
  )
  */




  /* CONTADOR
  return (
    <>
      <Contador />
      <ChangeFace />
    </>
  )
  */
}

export default App
