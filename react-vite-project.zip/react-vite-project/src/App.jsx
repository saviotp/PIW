import './App.css'
import BoasVindas from './BoasVindas'
import CadastroUsuario from './CadastroUsuario'
import ListarUsuario from './ListarUsuario'
import ListarNomes from './ListarNomes';
import ListaCores from './ListaCores';

function App() {

  let usuarioDB = "Sidartha";

  let usuarioSistema = {nome: "Sidartha", email: "sidartha@ufc.br", curso: "Design Digital"}

  let nomesUsuarios = ["Joao", "Maria", "Pedro", "Roger"]

  let nomesCores = ["green", "blue", "salmon", "red", "yellow"]

  return (
    <> 
      <h1>PIW 01 - UFC Quixadá</h1>
      <BoasVindas nomeUsuario = {usuarioDB}/>
      <CadastroUsuario />
      <ListarUsuario usuario = {usuarioSistema}/>
      <ListarNomes arrayNomes = {nomesUsuarios}/>
      <ListaCores arrayCores = {nomesCores}/>
    </>
  )
}

export default App
