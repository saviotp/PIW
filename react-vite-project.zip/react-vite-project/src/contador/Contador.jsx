
//Usa-se para alterar o site para o usuario
import { useState } from "react";

export default function Contador() {

    //o usetate é usado assim
    //NÃO DÁ PRA USAR MAIS O LET QUANDO SE USA ELE
    const [contador, setContador] = useState(0)
    const [nomeUsuario, setNomeUsuario] = useState("Sem Nome")

    function aumentarContador() {
        console.log("Contador: " + contador)
        setContador(contador + 1);
        setNomeUsuario("Joao " + (contador + 1));
    }

    return (
        //o onClick é camelcase aqui 
        <div onClick={aumentarContador}>
            <h1>Contador</h1>
            <h3>{contador}</h3>

            <h3>Nome do usuário: {nomeUsuario}</h3>
        </div>
    )
}