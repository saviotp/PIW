import { useState } from "react";

export default function ChangeFace() {

    const [isHappy, setIsHappy] = useState(true);
    const [contador, setContador] = useState(1);

    function changeEmoji() {
        setIsHappy(!isHappy)
        console.log(isHappy)

        setContador(contador + 1)
    }

    return (
        <div>
            <h1 onClick={changeEmoji}> {isHappy ? "😄" : "😞"}</h1>
            <h3>contador: {contador}</h3>
        </div>
    )
}