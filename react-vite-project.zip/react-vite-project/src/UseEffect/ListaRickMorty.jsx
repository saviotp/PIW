import { useState, useEffect } from "react";
import "./ListaRickMorty.css"

export default function ListaRickMorty() {
    const [ personagens, setPersonagens ] = useState([]);
    const [ pesquisa, setPesquisa ] = useState("");
    
    useEffect ( () => {
        const procurarPersonagem = async() => {
            console.log(pesquisa);
            const apiURL = `https://rickandmortyapi.com/api/character/?name=${pesquisa}`;
    
            try {
                const resposta = await fetch(apiURL);
                console.log(resposta);

                if (!resposta.ok) {
                    if (resposta.status == 404) {
                        //setPersonagens([]);
                        console.log("tá entrando!")
                    } else {
                        throw new Error (`Deu ruim, o código do erro é: ${resposta.status}`)
                    }
                } else {
                    const dadosAPI = await resposta.json();
                    console.log(dadosAPI);
                    setPersonagens(dadosAPI.results)
                }
            }
            catch (err){
                console.error("Erro ao caçar personagens:", err)
            }
        };

        procurarPersonagem()

    },[pesquisa])// toda vez que a pesquisa muda, ele atualiza

    return (
        <div className="container">
            <h1>Personagens do desenho Rick and Morty</h1>
            <input type="text" className="pesquisa" placeholder="Cace um personagem" value={pesquisa} onChange={(evento) => setPesquisa(evento.target.value)} />

            <div className="tabela-personagens">
                {personagens.map(personagem => (
                    <div key={personagem.id} className="cartinha-personagem">
                        <img src={personagem.image} alt={personagem.name} />
                        <h3>{personagem.name}</h3>
                        <p>Espécie: {personagem.species}</p>
                        <p>Status: {personagem.status}</p>
                    </div>
                ))} 
            </div>
        </div>
    );
}
