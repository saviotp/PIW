export default function ShoppingListItem({nomeProduto, quantidadeProduto, comprado}) {

    //checa se o item foi comprado ou não
    let nomeClasseCss = comprado ? "comprado" : "pendente"


    function mostrarJanela() {
        alert("Voce clicou!")
    }
    return (

        <>
            <li class="nomeClasseCss">Nome do Produto: {nomeProduto} -- Quantidade do produto: {quantidadeProduto}</li>
        </>
    )
}
