import ShoppingListItem from "./ShoppingListItem"

export default function ShoppingListCart({ listaProdutos }) {
    return (
        <>
            <h1>Lista de Compras</h1>

            <ul>
                {
                    listaProdutos.map(produto => {
                        return <ShoppingListItem nomeProduto={produto.nome} quantidadeProduto={produto.quantidade} comprado={produto.comprado} />
                    })
                }
            </ul>

        </>
    )
}