export default function ListarNomes({arrayNomes}) {
    return (
        <>
            {arrayNomes.map( (nome) => {
                if (nome === "Roger") {
                    return <h2 style={ {color: "black", backgroundColor: "yellow"} }>{nome}</h2>
                }
                return <h2 style={ {color: "green", backgroundColor: "salmon"} }>{nome}</h2>
            }) }
        </>
    )
}