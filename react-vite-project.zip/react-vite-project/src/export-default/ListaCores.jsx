export default function ListaCores( {arrayCores} ) {
    return (
        <div>
            <ul>
                {arrayCores.map ( (nomeCor) => {
                    return <li style = {{color: nomeCor}} >Nome da cor é: {nomeCor}</li>
                })}
            </ul>
        </div>
    )
}