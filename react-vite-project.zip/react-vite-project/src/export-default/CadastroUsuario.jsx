export default function CadastroUsuario() {
    return (
        <div>
            Email: <input type="email" /> <br />
            Senha: <input type="password" /> <br />
            <button>Cadastrar</button>
        </div>
    )
}