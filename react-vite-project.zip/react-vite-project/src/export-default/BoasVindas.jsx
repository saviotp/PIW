export default function BoasVindas(props) {
    return(
        <h1>Seja bem vindo: {props.nomeUsuario}</h1>
    )
    /*
        Para passar um parâmetro numérico, use {}
    */
}