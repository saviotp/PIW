export default SlotMachine( {coluna1, coluna2, coluna3} ) {

    let resultado = "";
    let css = {};

    if (coluna1 == coluna2 && coluna2 == coluna3) {
        resultado = "Você ganhou!";
        css = {backgroundColor: "green"};
    } else {
        resultado = "Você perdeu... Tente novamente!"
        css = {backgroundColor: "red"};
    }

    return (
        <div style={css}>
            <h2></h2>
        </div>
    )

}