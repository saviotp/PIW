export default function ListarUsuario(props) {
    return(
        <div>
            Nome: {props.usuario.nome}
            Email: {props.usuario.email}
            Curso:
        </div>
    )
}