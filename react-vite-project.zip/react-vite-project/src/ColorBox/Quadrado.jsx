import Quadradinho from "./Quadradinho"
import "./Quadrado.css"


export default function Quadrado() {
    function criarQuadradinhos() {

        let Quadradinhos = [];

        for(let i = 0; i < 25; i++) {
            Quadradinhos.push(<Quadradinho corInicial="brown" />);
        }
        return Quadradinhos;
    }
    return(
        <div className="quadrado">
            {criarQuadradinhos()}
        </div>
    )
}