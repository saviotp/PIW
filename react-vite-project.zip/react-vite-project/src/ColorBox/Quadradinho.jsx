import { useState } from "react";
import "./Quadradinho.css"

export default function Quadradinho( {corInicial} ) {

    const [cor, setCor] = useState(corInicial);

    function AlterarCor() {
        let random1 = Math.floor(Math.random() * 255)
        let random2 = Math.floor(Math.random() * 255)
        let random3 = Math.floor(Math.random() * 255)
        setCor = (`rgb(${random1}, ${random2}, ${random3})`);
        console.log(cor);
    }

    return(
        <div className="quadradinho" style={ {backgroundColor: cor} } onClick={AlterarCor}>
            
        </div>
    )
}